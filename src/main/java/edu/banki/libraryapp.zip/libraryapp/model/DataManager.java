package edu.banki.libraryapp.model;

import java.util.ArrayList;
import java.util.List;

public class DataManager {

    private static final List<Book> books = new ArrayList<>();
}
